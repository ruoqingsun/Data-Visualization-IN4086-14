##About the folder and language used

The python code in folder "within_distance" is used to calculate data within distance mean and variance, and is writtern in python.

The code in the rest folder, zone_change, dataset_used and opening strategy are written in ipython notebook, and are used to calculate zone change, used dataset and opening strategy respectively.